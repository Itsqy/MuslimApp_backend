
<?php $__env->startSection('content'); ?>
<div class="col-12">
    <div class="card recent-sales overflow-auto">

     
      
      <div class="card-body">
        
        
        <?php if($emas): ?>
            <div class="d-flex justify-content-end" style="margin-block-start: -0.5%"  ><a class="btn btn-primary" href="<?php echo e(route('toFormEmas')); ?>" > <i class="bi bi-plus"></i></a></div>             
        <?php else: ?>

        <div class="d-flex justify-content-end" style="margin-block-start: -0.5%"  ><a class="btn btn-primary"  href="<?php echo e(route('toFormEmas')); ?>" > <i class="bi bi-pencil"></i></a></div>             
        
        <?php endif; ?>
        
        <h5 class="card-title ">API Emas <span> | Zona Umum</span></h5>

        <table class="table table-borderless datatable">
          <thead>
            <tr>

              <th scope="col">id</th>
              <th scope="col">Harga Emas</th>
              <th scope="col">Tanggal</th>
              <th scope="col">Action</th>
              
            </tr>
          </thead>
          <tbody>

            <?php $__currentLoopData = $emas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><a href="#"><?php echo e($d->id); ?></a></th>
                <td>Rp. <?php echo e(number_format($d->hargaemas)); ?></td>
                <td><?php echo e($d->created_at); ?></td>
                <td><a href="<?php echo e(route('editEmas',$d->id)); ?>"><i class="bi bi-pencil"></i></a>
                  
                  
                  
                   <form action="<?php echo e(route('deleteEmas', $d->id)); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <?php echo method_field('DELETE'); ?>
                                                            <button type="submit" data-toggle="tooltip" title=""
                                                                class="btn btn-link btn-danger">
                                                                <i class="bi bi-trash"></i>
                                                            </button>
                                                        </form>

              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          </tbody>
        </table>

      </div>

    </div>
  </div><!-- End Recent Sales -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\Muslim_App\resources\views/content/emas/emas.blade.php ENDPATH**/ ?>